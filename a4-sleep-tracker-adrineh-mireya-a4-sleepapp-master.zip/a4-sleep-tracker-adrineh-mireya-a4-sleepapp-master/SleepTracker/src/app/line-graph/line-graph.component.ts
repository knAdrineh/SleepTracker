import { Component, Input, Output, EventEmitter,OnChanges, SimpleChanges } from '@angular/core';
import Chart from 'chart.js/auto';
import { OvernightSleepData } from '../data/overnight-sleep-data';

@Component({
  selector: 'app-line-graph',
  templateUrl: './line-graph.component.html',
  styleUrls: ['./line-graph.component.scss'],
})
export class LineGraphComponent  implements OnChanges {
   public chart: any;
   average_week: number = 0;
   @Output() average_weekEmit = new EventEmitter<number>();
  //@Input() objectArr: any[] = []; //holds the data of either overnight sleep or daily sleep
  @Input() objectArr2: OvernightSleepData[] = []; //holds the data of either overnight sleep or daily sleep

  overNightSleepData = [
    { date: 'Mon', hours: 0 },
    { date: 'Tue', hours: 0 },
    { date: 'Wed', hours: 0 },
    { date: 'Thu', hours: 0 },
    { date: 'Fri', hours: 0 },
    { date: 'Sat', hours: 0 },
    { date: 'Sun', hours: 0 },
  ];



  constructor() { }


  ngOnChanges(changes: SimpleChanges): void {
    if (changes['objectArr2'] && changes['objectArr2'].currentValue.length > 0) {
      this.createChart();
    }
  }

  setAverage(): void{
    this.average_week = 0;
    for(let index of this.overNightSleepData){
      this.average_week += index.hours;
    }
    this.average_week = this.average_week/7; //divide the averaege by 7 days cause we are calculating days of the week
    this.average_week = parseFloat(this.average_week.toFixed(2));
  }

  parseData(): void{
    for (let object of this.objectArr2)
    {
      // Get the sleep start date
      const sleepStartDate = object.getSleepStart();
      
      // Get the day of the week as "Mon", "Tue", etc.
      const dayOfWeek = sleepStartDate.toLocaleDateString('en-US', { weekday: 'short' });

      //get calculate time slept that day
      //ugly math because i had to convert from ms to hours
      let hoursSlept = -1 * (sleepStartDate.getTime() - object.getSleepEnd().getTime()) / (1000 * 60 * 60);
         // Round hoursSlept to the tenth decimal point
         hoursSlept = parseFloat(hoursSlept.toFixed(1));

      // Find the corresponding entry in oveNightSleepData and update its hours
      const entryToUpdate = this.overNightSleepData.find(entry => entry.date === dayOfWeek);
      if (entryToUpdate) {
          entryToUpdate.hours = hoursSlept; // Update this with the actual number of hours
          this.average_week += hoursSlept/2;
      }
    }

    this.setAverage();
    this.average_weekEmit.emit(this.average_week);
  }

  createChart(): void {
    //populate the overNightSleepData array
    this.parseData();

    const dates = this.overNightSleepData.map(data => data.date);  //an array of days of the week
    const hoursSlept = this.overNightSleepData.map(data => data.hours); //an array of average hours slept per night

    this.chart = new Chart('sleepChart', {
      type: 'line',
      data: {
        labels: dates,
        datasets: [{
          label: 'Average nightly hours slept',
          data: hoursSlept,
          fill: false,
          borderColor: '#735DA5',
          backgroundColor: '#70559e',
          tension: 0.4
        }]
      },
      options: {
        //maintainAspectRatio: false,
        responsive: true,
        scales: {
          x: {
            title: {
              display: true,
              text: 'Day',
              font: {
                weight: 'bold' 
              }
            }
          },
          y: {
            title: {
              display: true,
              text: 'Hours Slept',
              font: {
                weight: 'bold' 
              }
            }
          }
        }
      }
    });
  }

}
