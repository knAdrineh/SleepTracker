import { Component, OnInit, EventEmitter , Input, Output } from '@angular/core';

@Component({
  selector: 'app-rating-system',
  templateUrl: './rating-system.component.html',
  styleUrls: ['./rating-system.component.scss'],
})
export class RatingSystemComponent  implements OnInit {
  @Input() numOptions: number = 0;
  options:number[] = []; //this is going to hold how many stars we want to display for rating
  @Input() rating: number = 0;
  @Output() ratingChange = new EventEmitter<number>(); 
  //when a button on a child component is clicked, the child component employs an EventEmitter to inform the parent component of the button click.
  //The emitted event can be listened to by the parent component through the use of the @Input() decorator. 
  //The sending of an event is done through the EventEmitter.emit() method.
  
  constructor() { 
  }

  ngOnInit() {
    this.options = []; // Clear any previous values
    for (let i = 0; i < this.numOptions; i++) {
      this.options.push(i+1);
    }
  }

  giveRate(chosenRate: number){
    console.log("Chosen Rating: " + chosenRate);
    this.rating = chosenRate;
    this.ratingChange.emit(this.rating); //this gets sent to the parent, however for now the parent isnt catching anything or usig this data
  }



}
