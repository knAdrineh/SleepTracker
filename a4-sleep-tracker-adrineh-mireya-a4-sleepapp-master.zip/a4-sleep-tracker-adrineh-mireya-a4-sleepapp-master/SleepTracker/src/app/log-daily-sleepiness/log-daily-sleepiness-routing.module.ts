import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LogDailySleepinessPage } from './log-daily-sleepiness.page';

const routes: Routes = [
  {
    path: '',
    component: LogDailySleepinessPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LogDailySleepinessPageRoutingModule {}
