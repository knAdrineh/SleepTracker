import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LogDailySleepinessPageRoutingModule } from './log-daily-sleepiness-routing.module';

import { LogDailySleepinessPage } from './log-daily-sleepiness.page';
import { RatingSystemComponentModule } from '../rating-system/rating-system.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RatingSystemComponentModule,
    LogDailySleepinessPageRoutingModule
  ],
  declarations: [LogDailySleepinessPage]
})
export class LogDailySleepinessPageModule {}
