import { Component, OnInit } from '@angular/core';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { AlertController } from '@ionic/angular';
import { SleepService } from '../services/sleep.service';
@Component({
  selector: 'app-log-daily-sleepiness',
  templateUrl: './log-daily-sleepiness.page.html',
  styleUrls: ['./log-daily-sleepiness.page.scss'],
})
export class LogDailySleepinessPage implements OnInit {
  moonsConfirmed = false;
  rating: number = 0;  //need this to get the rating of the user and pass it RatingSystem component
  numOptions: number = 7; //this has 7 because the stanford sleeping scale has 7
  selectedTime:string = '';
  ratingDef:string = '';
  stanfordSleepData !: StanfordSleepinessData;

  

  constructor(private sleepService : SleepService, private alertController : AlertController) { }
  
  async presentAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Missing Scale Value',
      message: message,
      buttons: ['OK'],
    });
  
    await alert.present();
  }
  
  ngOnInit() {

    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'America/Los_Angeles', // Use the appropriate time zone (e.g., America/New_York for US Eastern Time)
    };

    const currentDateTime = new Date().toLocaleString('en-US', options);
    this.selectedTime = `${currentDateTime.slice(6, 10)}-${currentDateTime.slice(0, 2)}-${currentDateTime.slice(3, 5)}T${currentDateTime.slice(12, 17)}:00`;
  }

    //do something with this eventually.  
    //this holds what the user voted about their sleepiness 1-7
  setRating($event:number){
    this.rating = $event;
    this.moonsConfirmed = true;
  }

  displayScaleDef(rate: number): string {
    const scaleValue = StanfordSleepinessData.ScaleValues[rate];
    if (typeof scaleValue === 'string') {
      return scaleValue;
    }
    return ''; // Return an empty string if the scale value is not found or not a string
  }

  submitData(){
    if(this.moonsConfirmed){
      this.stanfordSleepData = new StanfordSleepinessData(this.rating, new Date(this.selectedTime));
      this.sleepService.logSleepinessData(this.stanfordSleepData).subscribe({
        next: (response) => {
        },
        error: (error) => {
          console.error('Error Sleepniess data adding data', error);
        }
      });
      
    }
  
  }
  presentDisabledAlert() {
    this.presentAlert('Please enter a sleepiness value on the moon scale.');
  }
}
