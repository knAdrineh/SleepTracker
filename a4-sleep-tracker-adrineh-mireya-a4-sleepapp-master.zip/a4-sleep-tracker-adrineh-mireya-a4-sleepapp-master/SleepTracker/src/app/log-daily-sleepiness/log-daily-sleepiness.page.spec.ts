import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LogDailySleepinessPage } from './log-daily-sleepiness.page';

describe('LogDailySleepinessPage', () => {
  let component: LogDailySleepinessPage;
  let fixture: ComponentFixture<LogDailySleepinessPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(LogDailySleepinessPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
