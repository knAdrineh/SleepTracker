import { Injectable } from '@angular/core';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

//to be used when fetching the data 
interface overnightFetched 
{ 
	id: string
	loggedAt : string
	sleepEnd : string
	sleepStart: string
}

//to be used when fetching the data 
interface sleepinessFetched
{ 
	id: string
	loggedAt: string
	loggedValue: number
}

@Injectable({
  providedIn: 'root'
})


export class SleepService {
	private static LoadDefaultData:boolean = true;
	public static AllSleepData:SleepData[] = [];
	public static AllOvernightData:OvernightSleepData[] = [];
	public static AllSleepinessData:StanfordSleepinessData[] = [];
	private static overnightDataURL = 'https://sleeptracker-e1a19-default-rtdb.firebaseio.com/AllOvernightData.json';
	private static  sleepDataURL = 'https://sleeptracker-e1a19-default-rtdb.firebaseio.com/AllSleepData.json';
	private static  sleepinessDataURL = 'https://sleeptracker-e1a19-default-rtdb.firebaseio.com/AllSleepinessData.json';

	constructor(private http : HttpClient) {
		if(SleepService.LoadDefaultData) {
			this.addDefaultData();
		SleepService.LoadDefaultData = false;
	}
	}

	private addDefaultData() {
		this.logOvernightData(new OvernightSleepData(new Date('February 18, 2021 01:03:00'), new Date('February 18, 2021 09:25:00')));
		this.logSleepinessData(new StanfordSleepinessData(4, new Date('February 19, 2021 14:38:00')));
		this.logOvernightData(new OvernightSleepData(new Date('February 20, 2021 23:11:00'), new Date('February 21, 2021 08:03:00')));
	}
	//adding the data to the backend
	public logOvernightData(sleepData:OvernightSleepData):Observable<any>  {
		SleepService.AllSleepData.push(sleepData);
		SleepService.AllOvernightData.push(sleepData);
		 // Return the Observable from the HTTP POST request.
		 //we need to subscribe in the log-overnight-sleep.ts for it to work correctly when the use clicks the button!
		 return this.http.post(SleepService.overnightDataURL, sleepData);
	
	}

	public logSleepinessData(sleepData:StanfordSleepinessData) :Observable<any> {
		SleepService.AllSleepData.push(sleepData);
		SleepService.AllSleepinessData.push(sleepData);
		return this.http.post(SleepService.sleepinessDataURL, sleepData);
	}

	public fetchOvernightSleepData(): Observable<any> {
		return this.http.get<{[key: string]: overnightFetched}>(SleepService.overnightDataURL).pipe(
		  map(resData => {
			const tempData: OvernightSleepData[] = [];
			for (const key in resData) {
			  if (resData.hasOwnProperty(key)) {
				tempData.push(new OvernightSleepData(new Date(resData[key].sleepStart), new Date(resData[key].sleepEnd)));
			  }
			}
			SleepService.AllOvernightData = tempData;
			return tempData; 
		  })
		);
	  }
	
	  public fetchSleepinessData(): Observable<any> {
		return this.http.get<{[key: string]: sleepinessFetched}>(SleepService.sleepinessDataURL).pipe(
		  map(resData => {
			const tempData: StanfordSleepinessData[] = [];
			for (const key in resData) {
			  if (resData.hasOwnProperty(key)) {
				tempData.push(new StanfordSleepinessData(resData[key].loggedValue, new Date(resData[key].loggedAt)));
			  }
			}
			SleepService.AllSleepinessData = tempData;
			return tempData; 
		  })
		);
	  }
	

}
