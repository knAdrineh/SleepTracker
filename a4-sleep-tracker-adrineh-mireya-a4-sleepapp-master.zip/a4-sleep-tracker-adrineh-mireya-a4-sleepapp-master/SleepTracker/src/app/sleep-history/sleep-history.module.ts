import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SleepHistoryPageRoutingModule } from './sleep-history-routing.module';

import { SleepHistoryPage } from './sleep-history.page';
import { LineGraphComponentModule } from '../line-graph/line-graph.module';
import { BarGraphComponentModule } from '../bar-graph/bar-graph.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LineGraphComponentModule,
    BarGraphComponentModule,
    SleepHistoryPageRoutingModule
  ],
  declarations: [SleepHistoryPage]
})
export class SleepHistoryPageModule {}
