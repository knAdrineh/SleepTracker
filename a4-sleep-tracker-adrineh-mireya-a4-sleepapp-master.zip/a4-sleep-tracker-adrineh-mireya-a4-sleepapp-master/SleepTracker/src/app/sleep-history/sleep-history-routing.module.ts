import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SleepHistoryPage } from './sleep-history.page';

const routes: Routes = [
  {
    path: '',
    component: SleepHistoryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SleepHistoryPageRoutingModule {}
