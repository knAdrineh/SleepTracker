import { Component, OnInit, EventEmitter } from '@angular/core';
import { SleepData } from '../data/sleep-data';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { SleepService } from '../services/sleep.service';



@Component({
  selector: 'app-sleep-history',
  templateUrl: './sleep-history.page.html',
  styleUrls: ['./sleep-history.page.scss'],
})
export class SleepHistoryPage implements OnInit {
  AllSleepData:SleepData[] = [];
	AllOvernightData:OvernightSleepData[] = [];
  averageOND: number = 0;
	AllSleepinessData:StanfordSleepinessData[] = [];
  averageASD: number = 0;
  isONData: boolean = false; //check if we even have data to display, start with false cause AllOvernightData could be empty
  isASData: boolean = false; //check if we have any data in allSleepiness array

  constructor(private  sleepService : SleepService, ) { }

  ngOnInit() {
    //just want to knnow what the data is pulling from the back end
    this.sleepService.fetchOvernightSleepData().subscribe(
      response => {
        this.AllOvernightData = response;
        if (this.AllOvernightData.length != 0) {
          //set to true because we pulled data so we can actually show a graph now
          this.isONData =true;    
        }
      }
    );

    this.sleepService.fetchSleepinessData().subscribe(
      response => {
        this.AllSleepinessData =response;
        if (this.AllSleepinessData.length != 0) {
          //set to true because we pulled data so we can actually show a graph now
          this.isASData =true;    
        }
      }
    );
  }

  handleAverageOND($event: number): void {
    this.averageOND = $event;
  }
  handleAverageASD($event: number): void {
    this.averageASD = $event;
  }
}
