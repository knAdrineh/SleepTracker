import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { BarGraphComponent } from './bar-graph.component';
import { Component, OnInit, Input, SimpleChanges, OnChanges } from '@angular/core';
import Chart from 'chart.js/auto';



@NgModule({
  imports: [ CommonModule, FormsModule, IonicModule],
  declarations: [BarGraphComponent],
  exports: [BarGraphComponent]
})
export class BarGraphComponentModule {}