import { Component, Output,EventEmitter, Input, SimpleChanges, OnChanges } from '@angular/core';
import Chart from 'chart.js/auto';
import { StanfordSleepinessData } from '../data/stanford-sleepiness-data';
import { SleepService } from '../services/sleep.service';


@Component({
  selector: 'app-bar-graph',
  templateUrl: './bar-graph.component.html',
  styleUrls: ['./bar-graph.component.scss'],
})
export class BarGraphComponent  implements OnChanges {
  public bar_chart : any;
  average_week : number = 0;
  @Output() average_weekEmit = new EventEmitter<number>();
  @Input() sleepinessArr : StanfordSleepinessData[] = [];

  stanfordSleepinessData = [
    { date: 'Mon', loggedValue: 0 },
    { date: 'Tue', loggedValue: 0 },
    { date: 'Wed', loggedValue: 0 },
    { date: 'Thu', loggedValue: 0 },
    { date: 'Fri', loggedValue: 0 },
    { date: 'Sat', loggedValue: 0 },
    { date: 'Sun', loggedValue: 0 },
  ];
  constructor(private sleepService : SleepService) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['sleepinessArr'] && changes['sleepinessArr'].currentValue.length > 0) {
      this.createChart();
    }
      
  }

  setAverage(): void{
    this.average_week = 0;
    for(let index of this.stanfordSleepinessData){
      this.average_week += index.loggedValue;
    }
    this.average_week = this.average_week/7; //divide the averaege by 7 days cause we are calculating days of the week
    this.average_week = parseFloat(this.average_week.toFixed(2));
  }

  parseData(): void{
    let avgOfDays : number[] = [];
    for (let object of this.sleepinessArr){
        // Get the sleep start date
        const sleepStartDate = new Date(object.loggedAt);
        const loggedValue = object.getLoggedValue();
        // Get the day of the week as "Mon", "Tue", etc.
        const dayOfWeek = sleepStartDate.toLocaleDateString('en-US', { weekday: 'short' });

      // Find the corresponding entry in oveNightSleepData and update its hours
      const entryToUpdate = this.stanfordSleepinessData.find(entry => entry.date === dayOfWeek);
      if (entryToUpdate) {
        if(entryToUpdate.loggedValue != 0 )
          entryToUpdate.loggedValue += loggedValue/2 ;// if we found another value for the same day take the running average
        else
          entryToUpdate.loggedValue = loggedValue; // Update this with the actual number of hours
        this.average_week += loggedValue/2;
      }     

    }

    this.setAverage();
    this.average_weekEmit.emit(this.average_week);
  }
  createChart(): void{
    this.parseData();
    const dates = this.stanfordSleepinessData.map(data => data.date);  //an array of days of the week
    const hoursSlept = this.stanfordSleepinessData.map(data => data.loggedValue); //an array of average of logged value

    this.bar_chart = new Chart('sleepinessChart', {
      type: 'bar',
      data: {
        labels: dates,
        datasets: [{
          label: 'Average Daily Sleepiness',
          data: hoursSlept,
          borderColor: 'red',
          backgroundColor: '#70559e'
        }]
      },
      options: {
        //maintainAspectRatio: false,
        responsive: true,
        scales: {
          x: {
            title: {
              display: true,
              text: 'Day',
              font: {
                weight: 'bold' 
              }
            }
          },
          y: {
            title: {
              display: true,
              text: 'Sleepiness Scale',
              font: {
                weight: 'bold' 
              }
            }
          }
        }
      }
    });
  }

  }
  


