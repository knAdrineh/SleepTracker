import { Component, OnInit } from '@angular/core';
import { OvernightSleepData } from '../data/overnight-sleep-data';
import { SleepData } from '../data/sleep-data';
import { AlertController } from '@ionic/angular';
import { SleepService } from '../services/sleep.service';

@Component({
  selector: 'app-log-overnight-sleep',
  templateUrl: './log-overnight-sleep.page.html',
  styleUrls: ['./log-overnight-sleep.page.scss'],
})
export class LogOvernightSleepPage implements OnInit {
  timesConfirmed = false;
  startDateTime: string = '';
  endDateTime: string = '';
  overnightSleepData !: OvernightSleepData;


  constructor(private alertController: AlertController, private sleepService : SleepService) {}

  async presentAlert(message: string) {
    const alert = await this.alertController.create({
      header: 'Invalid Time',
      message: message,
      buttons: ['OK'],
    });
  
    await alert.present();
  }
  ngOnInit() {

      const options: Intl.DateTimeFormatOptions = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        timeZone: 'America/Los_Angeles', // Use the appropriate time zone (e.g., America/New_York for US Eastern Time)
      };

      const currentDateTime = new Date().toLocaleString('en-US', options);
      // Set both startDateTime and endDateTime to the current time in the desired format
      this.startDateTime = `${currentDateTime.slice(6, 10)}-${currentDateTime.slice(0, 2)}-${currentDateTime.slice(3, 5)}T${currentDateTime.slice(12, 17)}:00`;
      this.endDateTime = this.startDateTime;
  
     this.overnightSleepData = new OvernightSleepData(
      new Date(this.startDateTime),
      new Date(this.endDateTime)
    );
  }

  onDateTimeChanged(){
    if(new Date(this.startDateTime) <= new Date(this.endDateTime) ){
      this.timesConfirmed = true;
    }
    else{
      this.presentAlert('End time must be after start time.');
      this.timesConfirmed = false;
    }
  }

  addData(){
    if (this.timesConfirmed) {
      this.overnightSleepData = new OvernightSleepData(new Date(this.startDateTime),new Date(this.endDateTime));
      this.sleepService.logOvernightData(this.overnightSleepData).subscribe({
        next: (response) => {
        },
        error: (error) => {
          console.error('Error adding overnight data', error);
        }
      });
    }
  }
}
