--Readme document for 
    -Mireya Gonzalez, mireysg1@uci.edu, mireysg1 (42645816)
    - Adrineh Khodaverdian, adrinehk@uci.edu, adrinehk ( 35302770)

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

20/20
- 3/3 The ability to log overnight sleep
- 3/3 The ability to log sleepiness during the day
- 3/3 The ability to view these two categories of logged data
- 3/3 Either using a native device resource or backing up logged data
- 3/3 Following good principles of mobile design
- 3/3 Creating a compelling app
- 2/2 A readme and demo video which explains how these features were implemented and their design rationale

2. How long, in hours, did it take you to complete this assignment?
    48 hours each.



3. What online resources did you consult when completing this assignment? (list specific URLs)
    - https://www.w3schools.com/css/css_border_shorthand.asp
    - https://ionicframework.com/docs/api/grid
    - https://ionicframework.com/docs/api/datetime#global-theming
    - https://colorinverter.imageonline.co/
    - https://ionicframework.com/docs/api/alert
    - https://www.chartjs.org/docs/latest/configuration/responsive.html
    - https://www.chartjs.org/docs/latest/charts/line.html
    - https://www.chartjs.org/docs/latest/charts/bar.html
    - https://webflow.com/blog/best-color-combinations
    - https://www.youtube.com/watch?v=RTzi5DS7On4
    - https://ionic.io/ionicons/v4
    - https://www.youtube.com/watch?v=V4iMyVnQPqM
    - https://medium.com/@parrycima/easy-way-to-implement-ionic-alert-services-with-angular-4d22f8c83e4d




4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
 - I (Mireya) discussed with Angela Duran (another classmate) about what import 
   she used to make her graphs because I liked how they looked.



5. Is there anything special we need to know in order to run your code?
    Dimensions: Samsung Galaxy S8+ (360x740)



--Aim for no more than two sentences for each of the following questions.--


6. Did you design your app with a particular type of user in mind? If so, whom?
    No, but we did incorporate details we would have liked if we were users.



7. Did you design your app specifically for iOS or Android, or both?
    We leaned more towards android but more specifically "MD".
    Dimensions: Samsung Galaxy S8+ (360x740)

8. How can a person log overnight sleep in your app? Why did you choose to support logging overnight sleep in this way?
    A user must press the "log overnight sleep" button on the homepage.  
    They must enter a time and date for both start and end sleep time, then press submit.
    We chose this because it was simple and straightforward.

9. How can a person log sleepiness during the day in your app? Why did you choose to support logging sleepiness in this way?
    A user must press the "log daily sleepiness" button on the homepage.  
    They must enter a time, then press a moon on the rating scale.
    We chose this because it was simple, straightforward, and cute.


10. How can a person view the data they logged in your app? Why did you choose to support viewing logged data in this way?
    A user must press the "Sleep History" button on the homepage.  
    If they entered data, then a line and/or bar graph will appear.
    We chose this because the data was organized and presented in a simple to read manner.


11. Which feature choose--using a native device resource, backing up logged data, or both?
    Backing up logged Data.



12. If you used a native device resource, what feature did you add? How does this feature change the app's experience for a user?
    N/A


13. If you backed up logged data, where does it back up to?
    FireBase.
    https://console.firebase.google.com/u/0/project/sleeptracker-e1a19/database/sleeptracker-e1a19-default-rtdb/data


14. How does your app implement or follow principles of good mobile design?
    We have the call to action buttons displayed on the home page that help the user naviagate to the correct pages.
    Each page also contains a back arrow to navigate back to the home page.
    The submit buttons are on disabled mode if the user data is invalid, and it will show alerts on the UI indicating the error so that the user can not submit
    The buttons are not far away from each other.
    The app adheres to android styling conventions with its font, buttons, and error messages.
    We also have a pretty asthetic design.

